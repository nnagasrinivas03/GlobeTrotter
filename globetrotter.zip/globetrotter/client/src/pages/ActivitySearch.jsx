import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './ActivitySearch.css';

export default function ActivitySearch() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [activities, setActivities] = useState([]);
  const [categories, setCategories] = useState([]);
  const [filters, setFilters] = useState({
    search: '',
    category: '',
    city_id: searchParams.get('city_id') || '',
    min_cost: '',
    max_cost: ''
  });
  const [loading, setLoading] = useState(true);
  const tripId = searchParams.get('trip_id');
  const stopId = searchParams.get('stop_id');

  useEffect(() => {
    fetchActivities();
    fetchCategories();
  }, [filters]);

  const fetchActivities = async () => {
    try {
      setLoading(true);
      const params = {};
      if (filters.search) params.search = filters.search;
      if (filters.category) params.category = filters.category;
      if (filters.city_id) params.city_id = filters.city_id;
      if (filters.min_cost) params.min_cost = filters.min_cost;
      if (filters.max_cost) params.max_cost = filters.max_cost;

      const res = await axios.get('/api/activities', { params });
      setActivities(res.data);
    } catch (err) {
      console.error('Error fetching activities:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await axios.get('/api/activities/meta/categories');
      setCategories(res.data);
    } catch (err) {
      console.error('Error fetching categories:', err);
    }
  };

  const handleAddActivity = async (activityId) => {
    if (!tripId || !stopId) {
      alert('Please select a trip and stop first');
      return;
    }

    try {
      await axios.post(`/api/trips/stops/${stopId}/activities`, {
        activity_id: activityId,
        activity_date: new Date().toISOString().split('T')[0],
        cost: activities.find(a => a.id === activityId)?.cost || 0
      });
      alert('Activity added successfully!');
      if (tripId) {
        navigate(`/trips/${tripId}/itinerary`);
      }
    } catch (err) {
      alert('Failed to add activity');
    }
  };

  return (
    <div className="activity-search">
      <div className="page-header">
        <h1>Discover Activities</h1>
        <p>Find amazing things to do on your trip</p>
      </div>

      <div className="filters-panel">
        <div className="filter-row">
          <input
            type="text"
            placeholder="Search activities..."
            value={filters.search}
            onChange={(e) => setFilters({ ...filters, search: e.target.value })}
            className="search-input"
          />
          <select
            value={filters.category}
            onChange={(e) => setFilters({ ...filters, category: e.target.value })}
          >
            <option value="">All Categories</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
        <div className="filter-row">
          <input
            type="number"
            placeholder="Min Cost ($)"
            value={filters.min_cost}
            onChange={(e) => setFilters({ ...filters, min_cost: e.target.value })}
          />
          <input
            type="number"
            placeholder="Max Cost ($)"
            value={filters.max_cost}
            onChange={(e) => setFilters({ ...filters, max_cost: e.target.value })}
          />
        </div>
      </div>

      {tripId && stopId && (
        <div className="info-banner">
          Adding activities to your trip. They will be saved automatically.
        </div>
      )}

      {loading ? (
        <div className="loading">Loading activities...</div>
      ) : (
        <div className="activities-grid">
          {activities.map(activity => (
            <div key={activity.id} className="activity-card-search">
              {activity.image_url && (
                <div
                  className="activity-image"
                  style={{ backgroundImage: `url(${activity.image_url})` }}
                />
              )}
              <div className="activity-content">
                <div className="activity-header">
                  <h3>{activity.name}</h3>
                  {activity.category && (
                    <span className="category-tag">{activity.category}</span>
                  )}
                </div>
                {activity.description && (
                  <p className="activity-description">{activity.description}</p>
                )}
                <div className="activity-info">
                  {activity.cost !== null && (
                    <span className="activity-cost">💰 ${activity.cost}</span>
                  )}
                  {activity.duration_hours && (
                    <span className="activity-duration">⏱️ {activity.duration_hours}h</span>
                  )}
                </div>
                {tripId && stopId && (
                  <button
                    onClick={() => handleAddActivity(activity.id)}
                    className="add-activity-btn"
                  >
                    + Add to Trip
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {!loading && activities.length === 0 && (
        <div className="empty-state">
          <p>No activities found. Try adjusting your filters.</p>
        </div>
      )}
    </div>
  );
}

