import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import axios from 'axios';
import './CitySearch.css';

export default function CitySearch() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [cities, setCities] = useState([]);
  const [countries, setCountries] = useState([]);
  const [searchTerm, setSearchTerm] = useState(searchParams.get('search') || '');
  const [selectedCountry, setSelectedCountry] = useState(searchParams.get('country') || '');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCities();
    fetchCountries();
  }, []);

  useEffect(() => {
    fetchCities();
  }, [searchTerm, selectedCountry]);

  const fetchCities = async () => {
    try {
      setLoading(true);
      const params = {};
      if (searchTerm) params.search = searchTerm;
      if (selectedCountry) params.country = selectedCountry;
      
      const res = await axios.get('/api/cities', { params });
      setCities(res.data);
    } catch (err) {
      console.error('Error fetching cities:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchCountries = async () => {
    try {
      const res = await axios.get('/api/cities/meta/countries');
      setCountries(res.data);
    } catch (err) {
      console.error('Error fetching countries:', err);
    }
  };

  const handleSearch = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    setSearchParams({ ...Object.fromEntries(searchParams), search: value });
  };

  const handleCountryFilter = (e) => {
    const value = e.target.value;
    setSelectedCountry(value);
    if (value) {
      setSearchParams({ ...Object.fromEntries(searchParams), country: value });
    } else {
      const newParams = { ...Object.fromEntries(searchParams) };
      delete newParams.country;
      setSearchParams(newParams);
    }
  };

  return (
    <div className="city-search">
      <div className="page-header">
        <h1>Explore Cities</h1>
        <p>Discover amazing destinations for your next trip</p>
      </div>

      <div className="search-filters">
        <div className="search-bar">
          <input
            type="text"
            placeholder="Search cities or countries..."
            value={searchTerm}
            onChange={handleSearch}
            className="search-input"
          />
        </div>
        <div className="filter-group">
          <label>Filter by Country:</label>
          <select value={selectedCountry} onChange={handleCountryFilter}>
            <option value="">All Countries</option>
            {countries.map(country => (
              <option key={country.country} value={country.country}>
                {country.country}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading ? (
        <div className="loading">Loading cities...</div>
      ) : (
        <div className="cities-grid">
          {cities.map(city => (
            <div key={city.id} className="city-card-detailed">
              <div
                className="city-image-large"
                style={{ backgroundImage: `url(${city.image_url || 'https://via.placeholder.com/400'})` }}
              >
                <div className="city-overlay-detailed">
                  <h2>{city.name}</h2>
                  <p>{city.country}</p>
                </div>
              </div>
              <div className="city-details">
                <p className="city-description">{city.description || 'A beautiful destination waiting to be explored'}</p>
                <div className="city-stats">
                  <div className="stat">
                    <span className="stat-label">Cost Index</span>
                    <span className="stat-value">{city.cost_index}</span>
                  </div>
                  <div className="stat">
                    <span className="stat-label">Popularity</span>
                    <span className="stat-value">⭐ {city.popularity}</span>
                  </div>
                </div>
                <Link to={`/activities?city_id=${city.id}`} className="view-activities-btn">
                  View Activities →
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      {!loading && cities.length === 0 && (
        <div className="empty-state">
          <p>No cities found. Try adjusting your search.</p>
        </div>
      )}
    </div>
  );
}

