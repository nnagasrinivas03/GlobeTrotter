import { Outlet, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import './Layout.css';

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="layout">
      <nav className="navbar">
        <div className="nav-container">
          <Link to="/" className="nav-logo">
            🌍 GlobalTrotters
          </Link>
          <div className="nav-links">
            <Link to="/">Dashboard</Link>
            <Link to="/trips">My Trips</Link>
            <Link to="/trips/new">Plan New Trip</Link>
            <Link to="/cities">Cities</Link>
            <Link to="/profile">{user?.name || 'Profile'}</Link>
            <button onClick={handleLogout} className="logout-btn">Logout</button>
          </div>
        </div>
      </nav>
      <main className="main-content">
        <Outlet />
      </main>
    </div>
  );
}

