import express from 'express';
import { dbAll, dbGet } from '../database.js';

const router = express.Router();

// Get all cities (with optional search)
router.get('/', async (req, res) => {
  try {
    const { search, country } = req.query;
    let query = 'SELECT * FROM cities WHERE 1=1';
    const params = [];

    if (search) {
      query += ' AND (name LIKE ? OR country LIKE ?)';
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm);
    }

    if (country) {
      query += ' AND country = ?';
      params.push(country);
    }

    query += ' ORDER BY popularity DESC, name ASC';

    const cities = await dbAll(query, params);
    res.json(cities);
  } catch (error) {
    console.error('Get cities error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get single city
router.get('/:id', async (req, res) => {
  try {
    const city = await dbGet('SELECT * FROM cities WHERE id = ?', [req.params.id]);
    if (!city) {
      return res.status(404).json({ error: 'City not found' });
    }
    res.json(city);
  } catch (error) {
    console.error('Get city error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get countries list
router.get('/meta/countries', async (req, res) => {
  try {
    const countries = await dbAll('SELECT DISTINCT country, country_code FROM cities ORDER BY country');
    res.json(countries);
  } catch (error) {
    console.error('Get countries error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;

