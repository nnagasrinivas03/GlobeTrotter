import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import './BudgetBreakdown.css';

const COLORS = ['#667eea', '#764ba2', '#f093fb', '#4facfe', '#00f2fe'];

export default function BudgetBreakdown() {
  const { id } = useParams();
  const [trip, setTrip] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTrip();
  }, [id]);

  const fetchTrip = async () => {
    try {
      const res = await axios.get(`/api/trips/${id}`);
      setTrip(res.data);
    } catch (err) {
      console.error('Error fetching trip:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading budget...</div>;
  }

  if (!trip) {
    return <div className="error">Trip not found</div>;
  }

  const calculateBudget = () => {
    let totalActivities = 0;
    let totalAccommodation = 0;
    let totalTransport = 0;
    let totalMeals = 0; // Estimated

    if (trip.stops) {
      trip.stops.forEach(stop => {
        totalAccommodation += stop.accommodation_cost || 0;
        totalTransport += stop.transport_cost || 0;
        
        if (stop.activities) {
          stop.activities.forEach(activity => {
            totalActivities += activity.cost || 0;
          });
        }
      });

      // Estimate meals: $50 per day per person
      const startDate = new Date(trip.start_date);
      const endDate = new Date(trip.end_date);
      const days = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1;
      totalMeals = days * 50;
    }

    const total = totalActivities + totalAccommodation + totalTransport + totalMeals;

    return {
      activities: totalActivities,
      accommodation: totalAccommodation,
      transport: totalTransport,
      meals: totalMeals,
      total
    };
  };

  const budget = calculateBudget();
  const days = trip.stops ? trip.stops.reduce((acc, stop) => {
    const start = new Date(stop.arrival_date);
    const end = new Date(stop.departure_date);
    return acc + Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1;
  }, 0) : 0;

  const pieData = [
    { name: 'Activities', value: budget.activities },
    { name: 'Accommodation', value: budget.accommodation },
    { name: 'Transport', value: budget.transport },
    { name: 'Meals', value: budget.meals }
  ].filter(item => item.value > 0);

  const barData = trip.stops?.map(stop => {
    let stopActivities = 0;
    if (stop.activities) {
      stopActivities = stop.activities.reduce((sum, a) => sum + (a.cost || 0), 0);
    }
    return {
      city: stop.city_name,
      accommodation: stop.accommodation_cost || 0,
      transport: stop.transport_cost || 0,
      activities: stopActivities
    };
  }) || [];

  return (
    <div className="budget-breakdown">
      <div className="page-header">
        <h1>Budget Breakdown: {trip.name}</h1>
        <Link to={`/trips/${id}`} className="btn-secondary">Back to Trip</Link>
      </div>

      <div className="budget-summary">
        <div className="summary-card total">
          <h2>Total Budget</h2>
          <div className="amount">${budget.total.toFixed(2)}</div>
          {days > 0 && (
            <div className="per-day">${(budget.total / days).toFixed(2)} per day</div>
          )}
        </div>
        <div className="summary-card">
          <h3>Activities</h3>
          <div className="amount-small">${budget.activities.toFixed(2)}</div>
        </div>
        <div className="summary-card">
          <h3>Accommodation</h3>
          <div className="amount-small">${budget.accommodation.toFixed(2)}</div>
        </div>
        <div className="summary-card">
          <h3>Transport</h3>
          <div className="amount-small">${budget.transport.toFixed(2)}</div>
        </div>
        <div className="summary-card">
          <h3>Meals (Est.)</h3>
          <div className="amount-small">${budget.meals.toFixed(2)}</div>
        </div>
      </div>

      <div className="charts-section">
        <div className="chart-card">
          <h2>Budget Distribution</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => `$${value.toFixed(2)}`} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {barData.length > 0 && (
          <div className="chart-card">
            <h2>Cost by City</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="city" />
                <YAxis />
                <Tooltip formatter={(value) => `$${value.toFixed(2)}`} />
                <Legend />
                <Bar dataKey="accommodation" stackId="a" fill="#667eea" />
                <Bar dataKey="transport" stackId="a" fill="#764ba2" />
                <Bar dataKey="activities" stackId="a" fill="#f093fb" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="detailed-breakdown">
        <h2>Detailed Breakdown by City</h2>
        {trip.stops && trip.stops.length > 0 ? (
          <div className="city-breakdowns">
            {trip.stops.map(stop => {
              const activitiesCost = stop.activities?.reduce((sum, a) => sum + (a.cost || 0), 0) || 0;
              const stopTotal = (stop.accommodation_cost || 0) + (stop.transport_cost || 0) + activitiesCost;
              
              return (
                <div key={stop.id} className="city-breakdown-card">
                  <h3>{stop.city_name}</h3>
                  <div className="breakdown-items">
                    <div className="breakdown-item">
                      <span>Accommodation</span>
                      <span>${(stop.accommodation_cost || 0).toFixed(2)}</span>
                    </div>
                    <div className="breakdown-item">
                      <span>Transport</span>
                      <span>${(stop.transport_cost || 0).toFixed(2)}</span>
                    </div>
                    <div className="breakdown-item">
                      <span>Activities</span>
                      <span>${activitiesCost.toFixed(2)}</span>
                    </div>
                    <div className="breakdown-item total-item">
                      <span>Total</span>
                      <span>${stopTotal.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="no-data">No stops added to calculate budget</p>
        )}
      </div>
    </div>
  );
}

