import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import './MyTrips.css';

export default function MyTrips() {
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTrips();
  }, []);

  const fetchTrips = async () => {
    try {
      const res = await axios.get('/api/trips');
      setTrips(res.data);
    } catch (err) {
      console.error('Error fetching trips:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this trip?')) return;
    
    try {
      await axios.delete(`/api/trips/${id}`);
      setTrips(trips.filter(t => t.id !== id));
    } catch (err) {
      alert('Failed to delete trip');
    }
  };

  const calculateTotalBudget = (trip) => {
    const activityCost = trip.activity_cost || 0;
    const accTransCost = trip.accommodation_transport_cost || 0;
    return activityCost + accTransCost;
  };

  if (loading) {
    return <div className="loading">Loading trips...</div>;
  }

  return (
    <div className="my-trips">
      <div className="page-header">
        <h1>My Trips</h1>
        <Link to="/trips/new" className="primary-btn">➕ Plan New Trip</Link>
      </div>

      {trips.length === 0 ? (
        <div className="empty-state">
          <p>You haven't created any trips yet.</p>
          <Link to="/trips/new" className="primary-btn">Create Your First Trip</Link>
        </div>
      ) : (
        <div className="trips-list">
          {trips.map(trip => (
            <div key={trip.id} className="trip-item">
              <div className="trip-item-content">
                <div className="trip-item-header">
                  <h2>{trip.name}</h2>
                  <span className="trip-badge">{trip.stop_count || 0} stops</span>
                </div>
                {trip.description && (
                  <p className="trip-description">{trip.description}</p>
                )}
                <div className="trip-item-details">
                  <span>📅 {new Date(trip.start_date).toLocaleDateString()} - {new Date(trip.end_date).toLocaleDateString()}</span>
                  <span>💰 ${calculateTotalBudget(trip).toFixed(0)}</span>
                </div>
              </div>
              <div className="trip-item-actions">
                <Link to={`/trips/${trip.id}`} className="btn-secondary">View</Link>
                <Link to={`/trips/${trip.id}/itinerary`} className="btn-secondary">Edit</Link>
                <button onClick={() => handleDelete(trip.id)} className="btn-danger">Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

