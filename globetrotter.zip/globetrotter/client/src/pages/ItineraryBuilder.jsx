import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import './ItineraryBuilder.css';

export default function ItineraryBuilder() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [trip, setTrip] = useState(null);
  const [stops, setStops] = useState([]);
  const [cities, setCities] = useState([]);
  const [showCitySearch, setShowCitySearch] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStop, setSelectedStop] = useState(null);
  const [activities, setActivities] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTrip();
    fetchCities();
  }, [id]);

  useEffect(() => {
    if (stops.length > 0) {
      fetchActivitiesForStops();
    }
  }, [stops]);

  const fetchTrip = async () => {
    try {
      const res = await axios.get(`/api/trips/${id}`);
      setTrip(res.data);
      setStops(res.data.stops || []);
    } catch (err) {
      console.error('Error fetching trip:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchCities = async () => {
    try {
      const res = await axios.get('/api/cities');
      setCities(res.data);
    } catch (err) {
      console.error('Error fetching cities:', err);
    }
  };

  const fetchActivitiesForStops = async () => {
    const activitiesMap = {};
    for (const stop of stops) {
      try {
        const res = await axios.get(`/api/activities?city_id=${stop.city_id}`);
        activitiesMap[stop.id] = res.data;
      } catch (err) {
        console.error('Error fetching activities:', err);
      }
    }
    setActivities(activitiesMap);
  };

  const handleAddStop = async (city) => {
    if (!trip) return;

    const arrivalDate = stops.length === 0 
      ? trip.start_date 
      : new Date(Math.max(...stops.map(s => new Date(s.departure_date).getTime()))).toISOString().split('T')[0];
    
    const departureDate = new Date(new Date(arrivalDate).getTime() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    try {
      const res = await axios.post(`/api/trips/${id}/stops`, {
        city_id: city.id,
        arrival_date: arrivalDate,
        departure_date: departureDate,
        accommodation_cost: 0,
        transport_cost: 0
      });
      setStops([...stops, res.data]);
      setShowCitySearch(false);
      setSearchTerm('');
    } catch (err) {
      alert('Failed to add city');
    }
  };

  const handleDeleteStop = async (stopId) => {
    if (!window.confirm('Remove this city from your trip?')) return;
    
    try {
      await axios.delete(`/api/trips/stops/${stopId}`);
      setStops(stops.filter(s => s.id !== stopId));
    } catch (err) {
      alert('Failed to remove city');
    }
  };

  const handleAddActivity = async (stopId, activityId) => {
    const stop = stops.find(s => s.id === stopId);
    if (!stop) return;

    try {
      const activity = activities[stopId]?.find(a => a.id === activityId);
      await axios.post(`/api/trips/stops/${stopId}/activities`, {
        activity_id: activityId,
        activity_date: stop.arrival_date,
        cost: activity?.cost || 0
      });
      fetchTrip(); // Refresh to get updated activities
    } catch (err) {
      alert('Failed to add activity');
    }
  };

  const handleRemoveActivity = async (stopId, activityId) => {
    try {
      await axios.delete(`/api/trips/stops/${stopId}/activities/${activityId}`);
      fetchTrip(); // Refresh
    } catch (err) {
      alert('Failed to remove activity');
    }
  };

  const filteredCities = cities.filter(city =>
    city.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    city.country.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="itinerary-builder">
      <div className="page-header">
        <h1>Build Itinerary: {trip?.name}</h1>
        <div className="header-actions">
          <Link to={`/trips/${id}`} className="btn-secondary">Back to Trip</Link>
          <Link to={`/trips/${id}/view`} className="primary-btn">View Itinerary</Link>
        </div>
      </div>

      <div className="builder-content">
        <div className="stops-section">
          <div className="section-header">
            <h2>Cities ({stops.length})</h2>
            <button onClick={() => setShowCitySearch(!showCitySearch)} className="primary-btn">
              {showCitySearch ? 'Cancel' : '+ Add City'}
            </button>
          </div>

          {showCitySearch && (
            <div className="city-search-panel">
              <input
                type="text"
                placeholder="Search cities..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="search-input"
              />
              <div className="cities-list">
                {filteredCities.slice(0, 10).map(city => (
                  <div key={city.id} className="city-option" onClick={() => handleAddStop(city)}>
                    <div>
                      <strong>{city.name}</strong>, {city.country}
                    </div>
                    <div className="city-meta">
                      <span>Cost: {city.cost_index}</span>
                      <span>⭐ {city.popularity}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="stops-list">
            {stops.map((stop, index) => (
              <div key={stop.id} className="stop-builder-card">
                <div className="stop-header">
                  <div className="stop-info">
                    <h3>{index + 1}. {stop.city_name}, {stop.country}</h3>
                    <div className="stop-dates">
                      <input
                        type="date"
                        value={stop.arrival_date}
                        onChange={async (e) => {
                          try {
                            await axios.put(`/api/trips/stops/${stop.id}`, {
                              arrival_date: e.target.value
                            });
                            fetchTrip();
                          } catch (err) {
                            alert('Failed to update date');
                          }
                        }}
                      />
                      <span>to</span>
                      <input
                        type="date"
                        value={stop.departure_date}
                        onChange={async (e) => {
                          try {
                            await axios.put(`/api/trips/stops/${stop.id}`, {
                              departure_date: e.target.value
                            });
                            fetchTrip();
                          } catch (err) {
                            alert('Failed to update date');
                          }
                        }}
                      />
                    </div>
                  </div>
                  <button onClick={() => handleDeleteStop(stop.id)} className="btn-danger">Remove</button>
                </div>

                <div className="stop-costs">
                  <div className="cost-input">
                    <label>Accommodation ($)</label>
                    <input
                      type="number"
                      value={stop.accommodation_cost || 0}
                      onChange={async (e) => {
                        try {
                          await axios.put(`/api/trips/stops/${stop.id}`, {
                            accommodation_cost: parseFloat(e.target.value) || 0
                          });
                          fetchTrip();
                        } catch (err) {
                          alert('Failed to update cost');
                        }
                      }}
                    />
                  </div>
                  <div className="cost-input">
                    <label>Transport ($)</label>
                    <input
                      type="number"
                      value={stop.transport_cost || 0}
                      onChange={async (e) => {
                        try {
                          await axios.put(`/api/trips/stops/${stop.id}`, {
                            transport_cost: parseFloat(e.target.value) || 0
                          });
                          fetchTrip();
                        } catch (err) {
                          alert('Failed to update cost');
                        }
                      }}
                    />
                  </div>
                </div>

                <div className="stop-activities-section">
                  <h4>Activities</h4>
                  {stop.activities && stop.activities.length > 0 && (
                    <div className="activities-list">
                      {stop.activities.map(activity => (
                        <div key={activity.id} className="activity-item">
                          <span>{activity.name}</span>
                          <button onClick={() => handleRemoveActivity(stop.id, activity.id)} className="btn-small">Remove</button>
                        </div>
                      ))}
                    </div>
                  )}
                  <Link to={`/activities?city_id=${stop.city_id}&trip_id=${id}&stop_id=${stop.id}`} className="btn-link">
                    + Add Activities
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

