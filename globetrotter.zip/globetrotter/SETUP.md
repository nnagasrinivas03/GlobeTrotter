# Setup Instructions

## Quick Start

1. **Install all dependencies**:
   ```bash
   npm run install-all
   ```

2. **Start the application**:
   ```bash
   npm run dev
   ```

   This will start both the backend (port 5000) and frontend (port 3000) servers.

## Manual Setup

### Backend Setup

1. Navigate to the server directory:
   ```bash
   cd server
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. (Optional) Create a `.env` file:
   ```
   PORT=5000
   JWT_SECRET=your-secret-key-change-this
   ```

4. Start the server:
   ```bash
   npm run dev
   ```

### Frontend Setup

1. Navigate to the client directory:
   ```bash
   cd client
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

## First Time Setup

The database will be automatically created and seeded with initial data (cities and activities) when you first start the server.

## Accessing the Application

- Frontend: http://localhost:3000
- Backend API: http://localhost:5000/api

## Creating Your First Trip

1. Sign up for a new account
2. Click "Plan New Trip"
3. Fill in trip details (name, dates, description)
4. Add cities to your itinerary
5. Add activities to each city
6. View your budget breakdown
7. Share your trip publicly (optional)

## Troubleshooting

### Port Already in Use
If port 5000 or 3000 is already in use, you can:
- Change the port in `server/index.js` (backend)
- Change the port in `client/vite.config.js` (frontend)

### Database Issues
If you encounter database errors:
- Delete `globetrotter.db` and restart the server
- The database will be recreated automatically

### Module Not Found Errors
Make sure you've run `npm install` in both the root, server, and client directories.

