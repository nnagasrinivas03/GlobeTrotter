import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { format } from 'date-fns';
import './ItineraryView.css';

export default function ItineraryView() {
  const { id } = useParams();
  const [trip, setTrip] = useState(null);
  const [viewMode, setViewMode] = useState('list'); // 'list' or 'calendar'
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTrip();
  }, [id]);

  const fetchTrip = async () => {
    try {
      const res = await axios.get(`/api/trips/${id}`);
      setTrip(res.data);
    } catch (err) {
      console.error('Error fetching trip:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading itinerary...</div>;
  }

  if (!trip) {
    return <div className="error">Trip not found</div>;
  }

  const allDays = [];
  if (trip.stops && trip.stops.length > 0) {
    const startDate = new Date(trip.start_date);
    const endDate = new Date(trip.end_date);
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      allDays.push(new Date(d));
    }
  }

  return (
    <div className="itinerary-view">
      <div className="page-header">
        <h1>{trip.name} - Itinerary</h1>
        <div className="view-controls">
          <button
            onClick={() => setViewMode('list')}
            className={viewMode === 'list' ? 'active' : ''}
          >
            List View
          </button>
          <button
            onClick={() => setViewMode('calendar')}
            className={viewMode === 'calendar' ? 'active' : ''}
          >
            Calendar View
          </button>
          <Link to={`/trips/${id}/calendar`} className="btn-secondary">Full Calendar</Link>
        </div>
      </div>

      {viewMode === 'list' ? (
        <div className="itinerary-list">
          {trip.stops && trip.stops.length > 0 ? (
            trip.stops.map((stop, index) => (
              <div key={stop.id} className="stop-section">
                <div className="stop-header-view">
                  <div className="stop-number-large">{index + 1}</div>
                  <div>
                    <h2>{stop.city_name}, {stop.country}</h2>
                    <p className="stop-date-range">
                      {format(new Date(stop.arrival_date), 'MMM d')} - {format(new Date(stop.departure_date), 'MMM d, yyyy')}
                    </p>
                  </div>
                </div>

                {stop.activities && stop.activities.length > 0 ? (
                  <div className="activities-grid">
                    {stop.activities.map(activity => (
                      <div key={activity.id} className="activity-card">
                        <h4>{activity.name}</h4>
                        {activity.description && <p>{activity.description}</p>}
                        <div className="activity-meta">
                          {activity.start_time && <span>🕐 {activity.start_time}</span>}
                          {activity.cost && <span>💰 ${activity.cost}</span>}
                          {activity.duration_hours && <span>⏱️ {activity.duration_hours}h</span>}
                          {activity.category && <span className="category-badge">{activity.category}</span>}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="no-activities">No activities planned for this stop</p>
                )}
              </div>
            ))
          ) : (
            <div className="empty-state">
              <p>No stops added to this trip yet.</p>
              <Link to={`/trips/${id}/itinerary`} className="primary-btn">Build Itinerary</Link>
            </div>
          )}
        </div>
      ) : (
        <div className="calendar-view">
          {allDays.map((day, idx) => {
            const dayStr = format(day, 'yyyy-MM-dd');
            const dayStops = trip.stops?.filter(s => {
              const arrival = new Date(s.arrival_date);
              const departure = new Date(s.departure_date);
              return day >= arrival && day <= departure;
            }) || [];
            
            return (
              <div key={idx} className="calendar-day">
                <div className="day-header">
                  <h3>{format(day, 'EEEE, MMM d')}</h3>
                </div>
                <div className="day-content">
                  {dayStops.map(stop => {
                    const dayActivities = stop.activities?.filter(a => a.activity_date === dayStr) || [];
                    return (
                      <div key={stop.id} className="day-stop">
                        <h4>📍 {stop.city_name}</h4>
                        {dayActivities.length > 0 ? (
                          <ul className="day-activities">
                            {dayActivities.map(activity => (
                              <li key={activity.id}>
                                {activity.start_time && <span className="time">{activity.start_time}</span>}
                                {activity.name}
                                {activity.cost && <span className="cost">${activity.cost}</span>}
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="no-activities-day">No activities scheduled</p>
                        )}
                      </div>
                    );
                  })}
                  {dayStops.length === 0 && (
                    <p className="no-stops">No stops on this day</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

