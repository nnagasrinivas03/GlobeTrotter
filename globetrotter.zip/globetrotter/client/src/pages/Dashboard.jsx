import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';
import './Dashboard.css';

export default function Dashboard() {
  const { user } = useAuth();
  const [trips, setTrips] = useState([]);
  const [popularCities, setPopularCities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [tripsRes, citiesRes] = await Promise.all([
        axios.get('/api/trips'),
        axios.get('/api/cities?search=&limit=6')
      ]);
      setTrips(tripsRes.data.slice(0, 5));
      setPopularCities(citiesRes.data.slice(0, 6));
    } catch (err) {
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  const calculateTotalBudget = (trip) => {
    const activityCost = trip.activity_cost || 0;
    const accTransCost = trip.accommodation_transport_cost || 0;
    return activityCost + accTransCost;
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Welcome back, {user?.name}! 👋</h1>
        <p>Plan your next adventure with GlobalTrotters</p>
      </div>

      <div className="dashboard-actions">
        <Link to="/trips/new" className="action-card primary-action">
          <span className="action-icon">➕</span>
          <h3>Plan New Trip</h3>
          <p>Create a customized multi-city itinerary</p>
        </Link>
        <Link to="/trips" className="action-card">
          <span className="action-icon">📋</span>
          <h3>My Trips</h3>
          <p>View all your travel plans</p>
        </Link>
        <Link to="/cities" className="action-card">
          <span className="action-icon">🌆</span>
          <h3>Explore Cities</h3>
          <p>Discover amazing destinations</p>
        </Link>
      </div>

      {trips.length > 0 && (
        <section className="dashboard-section">
          <h2>Recent Trips</h2>
          <div className="trips-grid">
            {trips.map(trip => (
              <Link key={trip.id} to={`/trips/${trip.id}`} className="trip-card">
                <div className="trip-card-header">
                  <h3>{trip.name}</h3>
                  <span className="trip-status">{trip.stop_count || 0} stops</span>
                </div>
                <div className="trip-card-dates">
                  {new Date(trip.start_date).toLocaleDateString()} - {new Date(trip.end_date).toLocaleDateString()}
                </div>
                <div className="trip-card-budget">
                  Budget: ${calculateTotalBudget(trip).toFixed(0)}
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      <section className="dashboard-section">
        <h2>Popular Destinations</h2>
        <div className="cities-grid">
          {popularCities.map(city => (
            <Link key={city.id} to={`/cities?search=${city.name}`} className="city-card">
              <div className="city-image" style={{ backgroundImage: `url(${city.image_url || 'https://via.placeholder.com/300'})` }}>
                <div className="city-overlay">
                  <h3>{city.name}</h3>
                  <p>{city.country}</p>
                </div>
              </div>
              <div className="city-info">
                <span className="city-cost">Cost Index: {city.cost_index}</span>
                <span className="city-popularity">⭐ {city.popularity}</span>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}

