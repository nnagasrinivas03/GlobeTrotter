import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import { dbGet, dbRun } from '../database.js';
import bcrypt from 'bcryptjs';

const router = express.Router();

// All routes require authentication
router.use(authenticateToken);

// Get current user profile
router.get('/me', async (req, res) => {
  try {
    const user = await dbGet(
      'SELECT id, email, name, photo, created_at FROM users WHERE id = ?',
      [req.user.id]
    );
    res.json(user);
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update user profile
router.put('/me', async (req, res) => {
  try {
    const { name, photo, email, password } = req.body;
    const updates = [];
    const params = [];

    if (name) {
      updates.push('name = ?');
      params.push(name);
    }

    if (photo !== undefined) {
      updates.push('photo = ?');
      params.push(photo);
    }

    if (email) {
      // Check if email is already taken
      const existing = await dbGet('SELECT id FROM users WHERE email = ? AND id != ?', [email, req.user.id]);
      if (existing) {
        return res.status(400).json({ error: 'Email already in use' });
      }
      updates.push('email = ?');
      params.push(email);
    }

    if (password) {
      const hashedPassword = await bcrypt.hash(password, 10);
      updates.push('password = ?');
      params.push(hashedPassword);
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    params.push(req.user.id);
    await dbRun(
      `UPDATE users SET ${updates.join(', ')} WHERE id = ?`,
      params
    );

    const updatedUser = await dbGet(
      'SELECT id, email, name, photo, created_at FROM users WHERE id = ?',
      [req.user.id]
    );

    res.json(updatedUser);
  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete user account
router.delete('/me', async (req, res) => {
  try {
    await dbRun('DELETE FROM users WHERE id = ?', [req.user.id]);
    res.json({ message: 'Account deleted successfully' });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;

