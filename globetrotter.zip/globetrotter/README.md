# GlobalTrotters - Travel Planning Application

A comprehensive full-stack web application for planning multi-city travel itineraries with budget tracking, activity discovery, and sharing capabilities.

## Features

### Core Functionality
- **User Authentication**: Secure login/signup with JWT tokens
- **Trip Management**: Create, edit, and delete multi-city trips
- **Itinerary Builder**: Add cities, dates, and activities to trips
- **City & Activity Search**: Discover destinations and things to do
- **Budget Tracking**: Cost breakdowns with visual charts
- **Calendar View**: Visual timeline of your trip
- **Public Sharing**: Share itineraries with unique links
- **User Profiles**: Manage account settings and preferences

### Database Features
- Relational database design with proper foreign keys
- Complex queries for trip data aggregation
- Efficient indexing for performance
- Seed data for cities and activities

## Tech Stack

### Backend
- **Node.js** with Express
- **SQLite** database (easily migratable to PostgreSQL)
- **JWT** for authentication
- **bcryptjs** for password hashing

### Frontend
- **React** with React Router
- **Vite** for fast development
- **Recharts** for data visualization
- **date-fns** for date manipulation
- Modern CSS with responsive design

## Project Structure

```
globetrotter/
├── server/              # Backend API
│   ├── routes/          # API route handlers
│   ├── middleware/      # Authentication middleware
│   ├── database.js      # Database setup
│   ├── seed.js          # Seed data
│   └── index.js         # Server entry point
├── client/              # Frontend React app
│   ├── src/
│   │   ├── pages/       # Page components
│   │   ├── components/  # Reusable components
│   │   └── contexts/    # React contexts
│   └── index.html
└── package.json         # Root package.json
```

## Installation

1. **Install dependencies**:
   ```bash
   npm run install-all
   ```

2. **Set up environment variables** (optional):
   Create a `.env` file in the `server/` directory:
   ```
   PORT=5000
   JWT_SECRET=your-secret-key-here
   ```

3. **Start the development servers**:
   ```bash
   npm run dev
   ```

   This will start:
   - Backend server on `http://localhost:5000`
   - Frontend dev server on `http://localhost:3000`

## Usage

1. **Sign Up**: Create a new account
2. **Create Trip**: Click "Plan New Trip" and fill in trip details
3. **Build Itinerary**: Add cities, set dates, and assign activities
4. **View Budget**: Check cost breakdowns and charts
5. **Share**: Make trip public and share the link

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### Trips
- `GET /api/trips` - Get all user trips
- `GET /api/trips/:id` - Get trip details
- `POST /api/trips` - Create new trip
- `PUT /api/trips/:id` - Update trip
- `DELETE /api/trips/:id` - Delete trip
- `GET /api/trips/public/:token` - Get public trip

### Stops & Activities
- `POST /api/trips/:id/stops` - Add city to trip
- `PUT /api/trips/stops/:stopId` - Update stop
- `DELETE /api/trips/stops/:stopId` - Remove stop
- `POST /api/trips/stops/:stopId/activities` - Add activity
- `DELETE /api/trips/stops/:stopId/activities/:activityId` - Remove activity

### Cities & Activities
- `GET /api/cities` - Search cities
- `GET /api/activities` - Search activities

### Users
- `GET /api/users/me` - Get current user
- `PUT /api/users/me` - Update profile
- `DELETE /api/users/me` - Delete account

## Database Schema

- **users**: User accounts
- **trips**: Travel plans
- **stops**: Cities in trips
- **cities**: City database
- **activities**: Activity database
- **stop_activities**: Junction table for activities in stops

## Future Enhancements

- Admin dashboard with analytics
- Email notifications
- Trip templates
- Collaborative trip planning
- Mobile app
- Integration with booking APIs
- Weather forecasts
- Currency conversion

## License

MIT

