import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import { dbGet, dbAll, dbRun } from '../database.js';
import crypto from 'crypto';

const router = express.Router();

// All routes require authentication
router.use(authenticateToken);

// Get all trips for user
router.get('/', async (req, res) => {
  try {
    const trips = await dbAll(
      `SELECT t.*, 
       COUNT(DISTINCT s.id) as stop_count,
       (SELECT SUM(sa.cost) FROM stop_activities sa 
        JOIN stops s ON sa.stop_id = s.id WHERE s.trip_id = t.id) as activity_cost,
       (SELECT SUM(s.accommodation_cost + s.transport_cost) FROM stops s WHERE s.trip_id = t.id) as accommodation_transport_cost
       FROM trips t
       LEFT JOIN stops s ON t.id = s.trip_id
       WHERE t.user_id = ?
       GROUP BY t.id
       ORDER BY t.created_at DESC`,
      [req.user.id]
    );

    res.json(trips);
  } catch (error) {
    console.error('Get trips error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get single trip with full details
router.get('/:id', async (req, res) => {
  try {
    const trip = await dbGet(
      'SELECT * FROM trips WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]
    );

    if (!trip) {
      return res.status(404).json({ error: 'Trip not found' });
    }

    // Get stops with city info
    const stops = await dbAll(
      `SELECT s.*, c.name as city_name, c.country, c.country_code, c.image_url as city_image
       FROM stops s
       JOIN cities c ON s.city_id = c.id
       WHERE s.trip_id = ?
       ORDER BY s.order_index, s.arrival_date`,
      [req.params.id]
    );

    // Get activities for each stop
    for (const stop of stops) {
      const activities = await dbAll(
        `SELECT sa.*, a.name, a.description, a.category, a.duration_hours, a.image_url
         FROM stop_activities sa
         JOIN activities a ON sa.activity_id = a.id
         WHERE sa.stop_id = ?
         ORDER BY sa.activity_date, sa.start_time`,
        [stop.id]
      );
      stop.activities = activities;
    }

    trip.stops = stops;

    res.json(trip);
  } catch (error) {
    console.error('Get trip error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create new trip
router.post('/', async (req, res) => {
  try {
    const { name, description, start_date, end_date, cover_photo } = req.body;

    if (!name || !start_date || !end_date) {
      return res.status(400).json({ error: 'Name, start_date, and end_date are required' });
    }

    const shareToken = crypto.randomBytes(16).toString('hex');

    const result = await dbRun(
      `INSERT INTO trips (user_id, name, description, start_date, end_date, cover_photo, share_token)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [req.user.id, name, description || '', start_date, end_date, cover_photo || null, shareToken]
    );

    const trip = await dbGet('SELECT * FROM trips WHERE id = ?', [result.lastID]);
    res.status(201).json(trip);
  } catch (error) {
    console.error('Create trip error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update trip
router.put('/:id', async (req, res) => {
  try {
    const { name, description, start_date, end_date, cover_photo, is_public } = req.body;

    // Verify ownership
    const trip = await dbGet('SELECT * FROM trips WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (!trip) {
      return res.status(404).json({ error: 'Trip not found' });
    }

    await dbRun(
      `UPDATE trips 
       SET name = COALESCE(?, name),
           description = COALESCE(?, description),
           start_date = COALESCE(?, start_date),
           end_date = COALESCE(?, end_date),
           cover_photo = COALESCE(?, cover_photo),
           is_public = COALESCE(?, is_public)
       WHERE id = ?`,
      [name, description, start_date, end_date, cover_photo, is_public, req.params.id]
    );

    const updatedTrip = await dbGet('SELECT * FROM trips WHERE id = ?', [req.params.id]);
    res.json(updatedTrip);
  } catch (error) {
    console.error('Update trip error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete trip
router.delete('/:id', async (req, res) => {
  try {
    const trip = await dbGet('SELECT * FROM trips WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (!trip) {
      return res.status(404).json({ error: 'Trip not found' });
    }

    await dbRun('DELETE FROM trips WHERE id = ?', [req.params.id]);
    res.json({ message: 'Trip deleted successfully' });
  } catch (error) {
    console.error('Delete trip error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Add stop to trip
router.post('/:id/stops', async (req, res) => {
  try {
    const { city_id, arrival_date, departure_date, accommodation_cost, transport_cost } = req.body;

    if (!city_id || !arrival_date || !departure_date) {
      return res.status(400).json({ error: 'city_id, arrival_date, and departure_date are required' });
    }

    // Verify trip ownership
    const trip = await dbGet('SELECT * FROM trips WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (!trip) {
      return res.status(404).json({ error: 'Trip not found' });
    }

    // Get current max order_index
    const maxOrder = await dbGet(
      'SELECT MAX(order_index) as max_order FROM stops WHERE trip_id = ?',
      [req.params.id]
    );
    const orderIndex = (maxOrder?.max_order ?? -1) + 1;

    const result = await dbRun(
      `INSERT INTO stops (trip_id, city_id, arrival_date, departure_date, order_index, accommodation_cost, transport_cost)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [req.params.id, city_id, arrival_date, departure_date, orderIndex, accommodation_cost || 0, transport_cost || 0]
    );

    const stop = await dbGet(
      `SELECT s.*, c.name as city_name, c.country, c.country_code
       FROM stops s
       JOIN cities c ON s.city_id = c.id
       WHERE s.id = ?`,
      [result.lastID]
    );

    res.status(201).json(stop);
  } catch (error) {
    console.error('Add stop error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update stop
router.put('/stops/:stopId', async (req, res) => {
  try {
    const { arrival_date, departure_date, accommodation_cost, transport_cost, order_index } = req.body;

    // Verify ownership through trip
    const stop = await dbGet(
      `SELECT s.* FROM stops s
       JOIN trips t ON s.trip_id = t.id
       WHERE s.id = ? AND t.user_id = ?`,
      [req.params.stopId, req.user.id]
    );

    if (!stop) {
      return res.status(404).json({ error: 'Stop not found' });
    }

    await dbRun(
      `UPDATE stops 
       SET arrival_date = COALESCE(?, arrival_date),
           departure_date = COALESCE(?, departure_date),
           accommodation_cost = COALESCE(?, accommodation_cost),
           transport_cost = COALESCE(?, transport_cost),
           order_index = COALESCE(?, order_index)
       WHERE id = ?`,
      [arrival_date, departure_date, accommodation_cost, transport_cost, order_index, req.params.stopId]
    );

    const updatedStop = await dbGet(
      `SELECT s.*, c.name as city_name, c.country, c.country_code
       FROM stops s
       JOIN cities c ON s.city_id = c.id
       WHERE s.id = ?`,
      [req.params.stopId]
    );

    res.json(updatedStop);
  } catch (error) {
    console.error('Update stop error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete stop
router.delete('/stops/:stopId', async (req, res) => {
  try {
    const stop = await dbGet(
      `SELECT s.* FROM stops s
       JOIN trips t ON s.trip_id = t.id
       WHERE s.id = ? AND t.user_id = ?`,
      [req.params.stopId, req.user.id]
    );

    if (!stop) {
      return res.status(404).json({ error: 'Stop not found' });
    }

    await dbRun('DELETE FROM stops WHERE id = ?', [req.params.stopId]);
    res.json({ message: 'Stop deleted successfully' });
  } catch (error) {
    console.error('Delete stop error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Add activity to stop
router.post('/stops/:stopId/activities', async (req, res) => {
  try {
    const { activity_id, activity_date, start_time, cost, notes } = req.body;

    if (!activity_id || !activity_date) {
      return res.status(400).json({ error: 'activity_id and activity_date are required' });
    }

    // Verify ownership
    const stop = await dbGet(
      `SELECT s.* FROM stops s
       JOIN trips t ON s.trip_id = t.id
       WHERE s.id = ? AND t.user_id = ?`,
      [req.params.stopId, req.user.id]
    );

    if (!stop) {
      return res.status(404).json({ error: 'Stop not found' });
    }

    const result = await dbRun(
      `INSERT INTO stop_activities (stop_id, activity_id, activity_date, start_time, cost, notes)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [req.params.stopId, activity_id, activity_date, start_time || null, cost || null, notes || null]
    );

    const activity = await dbGet(
      `SELECT sa.*, a.name, a.description, a.category, a.duration_hours, a.image_url
       FROM stop_activities sa
       JOIN activities a ON sa.activity_id = a.id
       WHERE sa.id = ?`,
      [result.lastID]
    );

    res.status(201).json(activity);
  } catch (error) {
    console.error('Add activity error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Remove activity from stop
router.delete('/stops/:stopId/activities/:activityId', async (req, res) => {
  try {
    // Verify ownership
    const stop = await dbGet(
      `SELECT s.* FROM stops s
       JOIN trips t ON s.trip_id = t.id
       WHERE s.id = ? AND t.user_id = ?`,
      [req.params.stopId, req.user.id]
    );

    if (!stop) {
      return res.status(404).json({ error: 'Stop not found' });
    }

    await dbRun(
      'DELETE FROM stop_activities WHERE id = ? AND stop_id = ?',
      [req.params.activityId, req.params.stopId]
    );

    res.json({ message: 'Activity removed successfully' });
  } catch (error) {
    console.error('Remove activity error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get public trip by share token
router.get('/public/:token', async (req, res) => {
  try {
    const trip = await dbGet(
      'SELECT * FROM trips WHERE share_token = ? AND is_public = 1',
      [req.params.token]
    );

    if (!trip) {
      return res.status(404).json({ error: 'Trip not found or not public' });
    }

    // Get user info (name only)
    const user = await dbGet('SELECT name FROM users WHERE id = ?', [trip.user_id]);
    trip.user_name = user?.name;

    // Get stops with city info
    const stops = await dbAll(
      `SELECT s.*, c.name as city_name, c.country, c.country_code, c.image_url as city_image
       FROM stops s
       JOIN cities c ON s.city_id = c.id
       WHERE s.trip_id = ?
       ORDER BY s.order_index, s.arrival_date`,
      [trip.id]
    );

    // Get activities for each stop
    for (const stop of stops) {
      const activities = await dbAll(
        `SELECT sa.*, a.name, a.description, a.category, a.duration_hours, a.image_url
         FROM stop_activities sa
         JOIN activities a ON sa.activity_id = a.id
         WHERE sa.stop_id = ?
         ORDER BY sa.activity_date, sa.start_time`,
        [stop.id]
      );
      stop.activities = activities;
    }

    trip.stops = stops;

    res.json(trip);
  } catch (error) {
    console.error('Get public trip error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;

