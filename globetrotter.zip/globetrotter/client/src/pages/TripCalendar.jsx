import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth, addMonths, subMonths } from 'date-fns';
import './TripCalendar.css';

export default function TripCalendar() {
  const { id } = useParams();
  const [trip, setTrip] = useState(null);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTrip();
  }, [id]);

  const fetchTrip = async () => {
    try {
      const res = await axios.get(`/api/trips/${id}`);
      setTrip(res.data);
      if (res.data.start_date) {
        setCurrentMonth(new Date(res.data.start_date));
      }
    } catch (err) {
      console.error('Error fetching trip:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading calendar...</div>;
  }

  if (!trip) {
    return <div className="error">Trip not found</div>;
  }

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const getActivitiesForDay = (day) => {
    if (!trip.stops) return [];
    const dayStr = format(day, 'yyyy-MM-dd');
    const activities = [];
    
    trip.stops.forEach(stop => {
      const arrival = new Date(stop.arrival_date);
      const departure = new Date(stop.departure_date);
      
      if (day >= arrival && day <= departure && stop.activities) {
        stop.activities.forEach(activity => {
          if (activity.activity_date === dayStr) {
            activities.push({ ...activity, city: stop.city_name });
          }
        });
      }
    });
    
    return activities;
  };

  const isTripDay = (day) => {
    if (!trip.start_date || !trip.end_date) return false;
    const start = new Date(trip.start_date);
    const end = new Date(trip.end_date);
    return day >= start && day <= end;
  };

  const getStopForDay = (day) => {
    if (!trip.stops) return null;
    return trip.stops.find(stop => {
      const arrival = new Date(stop.arrival_date);
      const departure = new Date(stop.departure_date);
      return day >= arrival && day <= departure;
    });
  };

  return (
    <div className="trip-calendar">
      <div className="page-header">
        <h1>Calendar: {trip.name}</h1>
        <Link to={`/trips/${id}`} className="btn-secondary">Back to Trip</Link>
      </div>

      <div className="calendar-controls">
        <button onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
          ← Previous
        </button>
        <h2>{format(currentMonth, 'MMMM yyyy')}</h2>
        <button onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
          Next →
        </button>
      </div>

      <div className="calendar-grid">
        <div className="calendar-weekdays">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="weekday">{day}</div>
          ))}
        </div>
        <div className="calendar-days">
          {daysInMonth.map(day => {
            const isInTrip = isTripDay(day);
            const stop = getStopForDay(day);
            const activities = getActivitiesForDay(day);
            const isSelected = selectedDay && isSameDay(day, selectedDay);
            
            return (
              <div
                key={day.toISOString()}
                className={`calendar-day-cell ${isInTrip ? 'trip-day' : ''} ${isSelected ? 'selected' : ''}`}
                onClick={() => setSelectedDay(day)}
              >
                <div className="day-number">{format(day, 'd')}</div>
                {stop && (
                  <div className="day-city">{stop.city_name}</div>
                )}
                {activities.length > 0 && (
                  <div className="day-activities-count">{activities.length} activities</div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {selectedDay && (
        <div className="day-details">
          <h3>{format(selectedDay, 'EEEE, MMMM d, yyyy')}</h3>
          {getStopForDay(selectedDay) && (
            <div className="day-stop-info">
              <h4>📍 {getStopForDay(selectedDay).city_name}</h4>
            </div>
          )}
          {getActivitiesForDay(selectedDay).length > 0 ? (
            <div className="day-activities-list">
              {getActivitiesForDay(selectedDay).map((activity, idx) => (
                <div key={idx} className="activity-item-calendar">
                  <div className="activity-time">{activity.start_time || 'All day'}</div>
                  <div className="activity-name">{activity.name}</div>
                  {activity.cost && (
                    <div className="activity-cost">${activity.cost}</div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="no-activities-day">No activities scheduled for this day</p>
          )}
        </div>
      )}
    </div>
  );
}

