import { dbGet, dbAll, dbRun } from './database.js';

export async function seedDatabase() {
  // Check if cities already exist
  const cityCount = await dbGet('SELECT COUNT(*) as count FROM cities');
  
  if (cityCount.count > 0) {
    console.log('Database already seeded');
    return;
  }

  // Seed cities
  const cities = [
    { name: 'Paris', country: 'France', country_code: 'FR', cost_index: 1.5, popularity: 95, description: 'City of Light', image_url: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800' },
    { name: 'Tokyo', country: 'Japan', country_code: 'JP', cost_index: 1.8, popularity: 92, description: 'Modern metropolis', image_url: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800' },
    { name: 'New York', country: 'United States', country_code: 'US', cost_index: 2.0, popularity: 98, description: 'The Big Apple', image_url: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800' },
    { name: 'London', country: 'United Kingdom', country_code: 'GB', cost_index: 1.7, popularity: 94, description: 'Historic capital', image_url: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800' },
    { name: 'Barcelona', country: 'Spain', country_code: 'ES', cost_index: 1.2, popularity: 88, description: 'Mediterranean gem', image_url: 'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=800' },
    { name: 'Rome', country: 'Italy', country_code: 'IT', cost_index: 1.4, popularity: 90, description: 'Eternal City', image_url: 'https://images.unsplash.com/photo-1529260830199-42c24126f198?w=800' },
    { name: 'Dubai', country: 'United Arab Emirates', country_code: 'AE', cost_index: 1.9, popularity: 85, description: 'Desert luxury', image_url: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800' },
    { name: 'Bali', country: 'Indonesia', country_code: 'ID', cost_index: 0.8, popularity: 87, description: 'Tropical paradise', image_url: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=800' },
    { name: 'Sydney', country: 'Australia', country_code: 'AU', cost_index: 1.6, popularity: 86, description: 'Harbor city', image_url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800' },
    { name: 'Amsterdam', country: 'Netherlands', country_code: 'NL', cost_index: 1.5, popularity: 83, description: 'Canal city', image_url: 'https://images.unsplash.com/photo-1534351590666-13e3e96b5017?w=800' },
  ];

  for (const city of cities) {
    await dbRun(
      `INSERT INTO cities (name, country, country_code, cost_index, popularity, description, image_url) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [city.name, city.country, city.country_code, city.cost_index, city.popularity, city.description, city.image_url]
    );
  }

  // Get city IDs for activities
  const cityList = await dbAll('SELECT id, name FROM cities');
  const cityMap = {};
  cityList.forEach(city => {
    cityMap[city.name] = city.id;
  });

  // Seed activities
  const activities = [
    // Paris activities
    { name: 'Eiffel Tower Visit', description: 'Iconic iron lattice tower', city_id: cityMap['Paris'], category: 'Sightseeing', cost: 25, duration_hours: 2 },
    { name: 'Louvre Museum', description: 'World-famous art museum', city_id: cityMap['Paris'], category: 'Culture', cost: 17, duration_hours: 4 },
    { name: 'Seine River Cruise', description: 'Scenic boat tour', city_id: cityMap['Paris'], category: 'Tour', cost: 15, duration_hours: 1.5 },
    { name: 'French Cooking Class', description: 'Learn to cook French cuisine', city_id: cityMap['Paris'], category: 'Food', cost: 80, duration_hours: 3 },
    
    // Tokyo activities
    { name: 'Shibuya Crossing', description: 'World\'s busiest intersection', city_id: cityMap['Tokyo'], category: 'Sightseeing', cost: 0, duration_hours: 0.5 },
    { name: 'Tokyo Skytree', description: 'Tallest tower in Japan', city_id: cityMap['Tokyo'], category: 'Sightseeing', cost: 20, duration_hours: 2 },
    { name: 'Sushi Making Class', description: 'Traditional sushi preparation', city_id: cityMap['Tokyo'], category: 'Food', cost: 60, duration_hours: 2.5 },
    { name: 'Senso-ji Temple', description: 'Ancient Buddhist temple', city_id: cityMap['Tokyo'], category: 'Culture', cost: 0, duration_hours: 1.5 },
    
    // New York activities
    { name: 'Statue of Liberty', description: 'Iconic symbol of freedom', city_id: cityMap['New York'], category: 'Sightseeing', cost: 24, duration_hours: 3 },
    { name: 'Central Park Walk', description: 'Famous urban park', city_id: cityMap['New York'], category: 'Outdoor', cost: 0, duration_hours: 2 },
    { name: 'Broadway Show', description: 'World-class theater', city_id: cityMap['New York'], category: 'Entertainment', cost: 120, duration_hours: 2.5 },
    { name: 'Metropolitan Museum', description: 'Premier art collection', city_id: cityMap['New York'], category: 'Culture', cost: 25, duration_hours: 4 },
    
    // London activities
    { name: 'Big Ben & Westminster', description: 'Historic landmarks', city_id: cityMap['London'], category: 'Sightseeing', cost: 0, duration_hours: 1.5 },
    { name: 'British Museum', description: 'World history collection', city_id: cityMap['London'], category: 'Culture', cost: 0, duration_hours: 3 },
    { name: 'Thames River Cruise', description: 'River sightseeing tour', city_id: cityMap['London'], category: 'Tour', cost: 20, duration_hours: 1.5 },
    { name: 'West End Show', description: 'Theater district performance', city_id: cityMap['London'], category: 'Entertainment', cost: 60, duration_hours: 2.5 },
    
    // Barcelona activities
    { name: 'Sagrada Familia', description: 'Gaudi\'s masterpiece', city_id: cityMap['Barcelona'], category: 'Sightseeing', cost: 26, duration_hours: 2 },
    { name: 'Park Güell', description: 'Colorful park with Gaudi designs', city_id: cityMap['Barcelona'], category: 'Sightseeing', cost: 10, duration_hours: 2 },
    { name: 'Tapas Tour', description: 'Traditional Spanish food tour', city_id: cityMap['Barcelona'], category: 'Food', cost: 45, duration_hours: 3 },
    { name: 'Beach Day', description: 'Mediterranean coastline', city_id: cityMap['Barcelona'], category: 'Outdoor', cost: 0, duration_hours: 4 },
    
    // Rome activities
    { name: 'Colosseum Tour', description: 'Ancient Roman amphitheater', city_id: cityMap['Rome'], category: 'Sightseeing', cost: 18, duration_hours: 2 },
    { name: 'Vatican Museums', description: 'Renaissance art collection', city_id: cityMap['Rome'], category: 'Culture', cost: 21, duration_hours: 3 },
    { name: 'Trevi Fountain', description: 'Baroque fountain', city_id: cityMap['Rome'], category: 'Sightseeing', cost: 0, duration_hours: 0.5 },
    { name: 'Italian Cooking Class', description: 'Learn authentic Italian recipes', city_id: cityMap['Rome'], category: 'Food', cost: 70, duration_hours: 3 },
  ];

  for (const activity of activities) {
    await dbRun(
      `INSERT INTO activities (name, description, city_id, category, cost, duration_hours) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [activity.name, activity.description, activity.city_id, activity.category, activity.cost, activity.duration_hours]
    );
  }

  console.log('Database seeded successfully');
}

