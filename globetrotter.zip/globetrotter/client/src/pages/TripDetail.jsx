import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './TripDetail.css';

export default function TripDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [trip, setTrip] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTrip();
  }, [id]);

  const fetchTrip = async () => {
    try {
      const res = await axios.get(`/api/trips/${id}`);
      setTrip(res.data);
    } catch (err) {
      console.error('Error fetching trip:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this trip?')) return;
    
    try {
      await axios.delete(`/api/trips/${id}`);
      navigate('/trips');
    } catch (err) {
      alert('Failed to delete trip');
    }
  };

  if (loading) {
    return <div className="loading">Loading trip...</div>;
  }

  if (!trip) {
    return <div className="error">Trip not found</div>;
  }

  return (
    <div className="trip-detail">
      <div className="trip-header">
        <div>
          <h1>{trip.name}</h1>
          {trip.description && <p className="trip-description">{trip.description}</p>}
          <div className="trip-meta">
            <span>📅 {new Date(trip.start_date).toLocaleDateString()} - {new Date(trip.end_date).toLocaleDateString()}</span>
            <span>📍 {trip.stops?.length || 0} cities</span>
          </div>
        </div>
        <div className="trip-actions">
          <Link to={`/trips/${id}/itinerary`} className="primary-btn">Edit Itinerary</Link>
          <button onClick={handleDelete} className="btn-danger">Delete Trip</button>
        </div>
      </div>

      <div className="trip-nav">
        <Link to={`/trips/${id}/view`} className="nav-link">📋 View Itinerary</Link>
        <Link to={`/trips/${id}/calendar`} className="nav-link">📅 Calendar View</Link>
        <Link to={`/trips/${id}/budget`} className="nav-link">💰 Budget</Link>
      </div>

      {trip.stops && trip.stops.length > 0 ? (
        <div className="stops-overview">
          <h2>Itinerary Overview</h2>
          <div className="stops-list">
            {trip.stops.map((stop, index) => (
              <div key={stop.id} className="stop-card">
                <div className="stop-number">{index + 1}</div>
                <div className="stop-content">
                  <h3>{stop.city_name}, {stop.country}</h3>
                  <p className="stop-dates">
                    {new Date(stop.arrival_date).toLocaleDateString()} - {new Date(stop.departure_date).toLocaleDateString()}
                  </p>
                  {stop.activities && stop.activities.length > 0 && (
                    <p className="stop-activities">{stop.activities.length} activities planned</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="empty-state">
          <p>No stops added yet. Start building your itinerary!</p>
          <Link to={`/trips/${id}/itinerary`} className="primary-btn">Add Cities</Link>
        </div>
      )}
    </div>
  );
}

