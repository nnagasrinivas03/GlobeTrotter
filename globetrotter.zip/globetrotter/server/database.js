import sqlite3 from 'sqlite3';
import { promisify } from 'util';
import { seedDatabase } from './seed.js';

const db = new sqlite3.Database('./globetrotter.db');

// Promisify database methods
const dbGet = promisify(db.get.bind(db));
const dbAll = promisify(db.all.bind(db));

// Custom dbRun that returns lastID
function dbRun(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) {
        reject(err);
      } else {
        resolve({ lastID: this.lastID, changes: this.changes });
      }
    });
  });
}

export { db, dbRun, dbGet, dbAll };

export async function initDatabase() {
  // Users table
  await dbRun(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      name TEXT NOT NULL,
      photo TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Trips table
  await dbRun(`
    CREATE TABLE IF NOT EXISTS trips (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      description TEXT,
      start_date DATE NOT NULL,
      end_date DATE NOT NULL,
      cover_photo TEXT,
      is_public INTEGER DEFAULT 0,
      share_token TEXT UNIQUE,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )
  `);

  // Stops table (cities in a trip)
  await dbRun(`
    CREATE TABLE IF NOT EXISTS stops (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      trip_id INTEGER NOT NULL,
      city_id INTEGER NOT NULL,
      arrival_date DATE NOT NULL,
      departure_date DATE NOT NULL,
      order_index INTEGER NOT NULL,
      accommodation_cost REAL DEFAULT 0,
      transport_cost REAL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE,
      FOREIGN KEY (city_id) REFERENCES cities(id)
    )
  `);

  // Cities table
  await dbRun(`
    CREATE TABLE IF NOT EXISTS cities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      country TEXT NOT NULL,
      country_code TEXT,
      cost_index REAL DEFAULT 1.0,
      popularity INTEGER DEFAULT 0,
      description TEXT,
      image_url TEXT
    )
  `);

  // Activities table
  await dbRun(`
    CREATE TABLE IF NOT EXISTS activities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT,
      city_id INTEGER,
      category TEXT,
      cost REAL DEFAULT 0,
      duration_hours REAL DEFAULT 1.0,
      image_url TEXT,
      FOREIGN KEY (city_id) REFERENCES cities(id)
    )
  `);

  // Stop Activities (junction table)
  await dbRun(`
    CREATE TABLE IF NOT EXISTS stop_activities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      stop_id INTEGER NOT NULL,
      activity_id INTEGER NOT NULL,
      activity_date DATE NOT NULL,
      start_time TEXT,
      cost REAL,
      notes TEXT,
      FOREIGN KEY (stop_id) REFERENCES stops(id) ON DELETE CASCADE,
      FOREIGN KEY (activity_id) REFERENCES activities(id)
    )
  `);

  // Create indexes for better performance
  await dbRun(`CREATE INDEX IF NOT EXISTS idx_trips_user ON trips(user_id)`);
  await dbRun(`CREATE INDEX IF NOT EXISTS idx_stops_trip ON stops(trip_id)`);
  await dbRun(`CREATE INDEX IF NOT EXISTS idx_activities_city ON activities(city_id)`);
  await dbRun(`CREATE INDEX IF NOT EXISTS idx_stop_activities_stop ON stop_activities(stop_id)`);

  // Seed database with initial data
  await seedDatabase();
}

