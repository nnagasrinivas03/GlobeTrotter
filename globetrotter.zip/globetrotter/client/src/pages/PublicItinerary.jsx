import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { format } from 'date-fns';
import './PublicItinerary.css';

export default function PublicItinerary() {
  const { token } = useParams();
  const [trip, setTrip] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetchTrip();
  }, [token]);

  const fetchTrip = async () => {
    try {
      const res = await axios.get(`/api/trips/public/${token}`);
      setTrip(res.data);
    } catch (err) {
      console.error('Error fetching public trip:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  if (loading) {
    return <div className="loading">Loading itinerary...</div>;
  }

  if (!trip) {
    return (
      <div className="error-container">
        <h1>Itinerary Not Found</h1>
        <p>This itinerary may be private or the link is invalid.</p>
      </div>
    );
  }

  return (
    <div className="public-itinerary">
      <div className="public-header">
        <h1>{trip.name}</h1>
        {trip.user_name && <p className="by-line">by {trip.user_name}</p>}
        {trip.description && <p className="trip-description">{trip.description}</p>}
        <div className="trip-meta">
          <span>📅 {format(new Date(trip.start_date), 'MMM d')} - {format(new Date(trip.end_date), 'MMM d, yyyy')}</span>
          <span>📍 {trip.stops?.length || 0} cities</span>
        </div>
        <div className="share-actions">
          <button onClick={handleShare} className="share-btn">
            {copied ? '✓ Copied!' : '📋 Copy Link'}
          </button>
        </div>
      </div>

      {trip.stops && trip.stops.length > 0 ? (
        <div className="itinerary-content">
          {trip.stops.map((stop, index) => (
            <div key={stop.id} className="stop-section-public">
              <div className="stop-header-public">
                <div className="stop-number-public">{index + 1}</div>
                <div>
                  <h2>{stop.city_name}, {stop.country}</h2>
                  <p className="stop-dates-public">
                    {format(new Date(stop.arrival_date), 'MMM d')} - {format(new Date(stop.departure_date), 'MMM d, yyyy')}
                  </p>
                </div>
              </div>

              {stop.activities && stop.activities.length > 0 && (
                <div className="activities-list-public">
                  <h3>Activities</h3>
                  <div className="activities-grid-public">
                    {stop.activities.map(activity => (
                      <div key={activity.id} className="activity-card-public">
                        <h4>{activity.name}</h4>
                        {activity.description && <p>{activity.description}</p>}
                        <div className="activity-meta-public">
                          {activity.start_time && <span>🕐 {activity.start_time}</span>}
                          {activity.cost && <span>💰 ${activity.cost}</span>}
                          {activity.category && <span className="category">{activity.category}</span>}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <p>No stops added to this itinerary yet.</p>
        </div>
      )}

      <div className="public-footer">
        <p>Created with 🌍 GlobalTrotters</p>
      </div>
    </div>
  );
}

