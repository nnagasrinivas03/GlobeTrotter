import express from 'express';
import { dbAll, dbGet } from '../database.js';

const router = express.Router();

// Get activities (with optional filters)
router.get('/', async (req, res) => {
  try {
    const { city_id, category, search, min_cost, max_cost } = req.query;
    let query = 'SELECT * FROM activities WHERE 1=1';
    const params = [];

    if (city_id) {
      query += ' AND city_id = ?';
      params.push(city_id);
    }

    if (category) {
      query += ' AND category = ?';
      params.push(category);
    }

    if (search) {
      query += ' AND (name LIKE ? OR description LIKE ?)';
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm);
    }

    if (min_cost !== undefined) {
      query += ' AND cost >= ?';
      params.push(min_cost);
    }

    if (max_cost !== undefined) {
      query += ' AND cost <= ?';
      params.push(max_cost);
    }

    query += ' ORDER BY name ASC';

    const activities = await dbAll(query, params);
    res.json(activities);
  } catch (error) {
    console.error('Get activities error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get single activity
router.get('/:id', async (req, res) => {
  try {
    const activity = await dbGet('SELECT * FROM activities WHERE id = ?', [req.params.id]);
    if (!activity) {
      return res.status(404).json({ error: 'Activity not found' });
    }
    res.json(activity);
  } catch (error) {
    console.error('Get activity error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get activity categories
router.get('/meta/categories', async (req, res) => {
  try {
    const categories = await dbAll('SELECT DISTINCT category FROM activities WHERE category IS NOT NULL ORDER BY category');
    res.json(categories.map(c => c.category));
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;

